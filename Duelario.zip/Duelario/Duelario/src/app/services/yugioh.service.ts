import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, catchError, throwError } from 'rxjs';
import { CardApiResponse } from '../models/card.model';

@Injectable({ providedIn: 'root' })
export class YugiohService {
  private readonly http = inject(HttpClient);

  /** Endpoint base de la API pública de YGOPRODeck v7 */
  private readonly API_URL = 'https://db.ygoprodeck.com/api/v7/cardinfo.php';

  /**
   * Búsqueda fuzzy de cartas por nombre parcial usando el parámetro `fname`.
   * Los datos provienen exclusivamente de la API de YGOPRODeck.
   */
  searchCards(fname: string): Observable<CardApiResponse> {
    return this.http
      .get<CardApiResponse>(this.API_URL, { params: { fname } })
      .pipe(
        catchError(err => {
          if (err.status === 400) {
            return throwError(() => new Error('Ninguna carta coincide con eso. Prueba con menos letras.'));
          }
          if (err.status === 429) {
            return throwError(() => new Error('Vas muy rápido: la API pidió una pausa. Espera unos segundos y reintenta.'));
          }
          return throwError(() => new Error('No pudimos conectar con la base de cartas. Revisa tu internet y vuelve a intentarlo.'));
        })
      );
  }

  /**
   * Obtiene todas las cartas del arquetipo "Blue-Eyes" desde la API.
   * El nombre del arquetipo no está hardcodeado en el componente;
   * se pasa como parámetro dinámico al endpoint.
   */
  getBlueEyesCards(): Observable<CardApiResponse> {
    return this.http
      .get<CardApiResponse>(this.API_URL, { params: { archetype: 'Blue-Eyes' } })
      .pipe(
        catchError(err => {
          if (err.status === 400) {
            return throwError(() => new Error('La base no devolvió cartas Blue-Eyes por ahora. Intenta de nuevo en un rato.'));
          }
          if (err.status === 429) {
            return throwError(() => new Error('Vas muy rápido: la API pidió una pausa. Espera unos segundos y reintenta.'));
          }
          return throwError(() => new Error('No logramos cargar el archivo Blue-Eyes. Revisa tu conexión y recarga la página.'));
        })
      );
  }
}
