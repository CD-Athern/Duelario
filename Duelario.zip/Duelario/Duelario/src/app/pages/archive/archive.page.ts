import { Component, OnInit, OnDestroy, signal, computed, inject } from '@angular/core';
import { Meta } from '@angular/platform-browser';
import { Subscription } from 'rxjs';
import { YugiohService } from '../../services/yugioh.service';
import { Card } from '../../models/card.model';

/** Una aparición concreta de una carta en una expansión. */
export interface PrintEntry {
  cardId: number;
  cardName: string;
  cardType: string;
  artUrl: string;
  setName: string;
  setCode: string;
  setRarity: string;
  /** Precio de esa impresión (card_sets[].set_price). */
  setPrice: string;
  /** Referencias de mercado (card_prices[0]). */
  cardmarket: string;
  tcgplayer: string;
}

type ArchivePhase = 'loading' | 'success' | 'error';

@Component({
  selector: 'dz-archive',
  standalone: true,
  imports: [],
  templateUrl: './archive.page.html',
  styleUrl: './archive.page.scss',
})
export class ArchivePage implements OnInit, OnDestroy {
  private readonly api = inject(YugiohService);
  private readonly meta = inject(Meta);

  readonly phase = signal<ArchivePhase>('loading');
  readonly failure = signal('');
  private readonly entries = signal<PrintEntry[]>([]);
  readonly sets = signal<string[]>([]);
  readonly activeSet = signal<string | null>(null);

  readonly visible = computed<PrintEntry[]>(() => {
    const set = this.activeSet();
    return set ? this.entries().filter(e => e.setName === set) : this.entries();
  });

  private sub!: Subscription;

  ngOnInit(): void {
    this.meta.updateTag({
      name: 'description',
      content: 'Todas las impresiones de Blue-Eyes por expansión: código, rareza y precio de cada una, con referencia de Cardmarket y TCGplayer.',
    });
    this.sub = this.api.getBlueEyesCards().subscribe({
      next: res => {
        const list = this.flatten(res.data ?? []);
        this.entries.set(list);
        this.sets.set(this.uniqueSets(list));
        this.phase.set('success');
      },
      error: err => { this.failure.set(err.message); this.phase.set('error'); },
    });
  }

  private flatten(cards: Card[]): PrintEntry[] {
    const out: PrintEntry[] = [];
    for (const c of cards) {
      for (const s of c.card_sets ?? []) {
        out.push({
          cardId: c.id,
          cardName: c.name,
          cardType: c.type,
          artUrl: c.card_images[0]?.image_url_small ?? '',
          setName: s.set_name,
          setCode: s.set_code,
          setRarity: s.set_rarity,
          setPrice: s.set_price,
          cardmarket: c.card_prices?.[0]?.cardmarket_price ?? '—',
          tcgplayer: c.card_prices?.[0]?.tcgplayer_price ?? '—',
        });
      }
    }
    return out;
  }

  private uniqueSets(list: PrintEntry[]): string[] {
    return [...new Set(list.map(e => e.setName))].sort((a, b) => a.localeCompare(b));
  }

  pickSet(name: string): void { this.activeSet.set(this.activeSet() === name ? null : name); }
  resetSet(): void { this.activeSet.set(null); }

  /** true si el valor trae un precio utilizable. */
  known(v: string | undefined): boolean { return !!v && v !== '—' && v !== '0.00'; }

  ngOnDestroy(): void { this.sub?.unsubscribe(); }
}
