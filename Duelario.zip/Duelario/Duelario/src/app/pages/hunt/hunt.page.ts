import { Component, OnInit, OnDestroy, signal, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Meta } from '@angular/platform-browser';
import { Subject, Subscription, EMPTY } from 'rxjs';
import { debounceTime, distinctUntilChanged, filter, switchMap, tap, catchError } from 'rxjs/operators';
import { YugiohService } from '../../services/yugioh.service';
import { Card } from '../../models/card.model';

type HuntPhase = 'idle' | 'loading' | 'success' | 'empty' | 'error';

@Component({
  selector: 'dz-hunt',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './hunt.page.html',
  styleUrl: './hunt.page.scss',
})
export class HuntPage implements OnInit, OnDestroy {
  private readonly api = inject(YugiohService);
  private readonly meta = inject(Meta);

  readonly phase = signal<HuntPhase>('idle');
  readonly hits = signal<Card[]>([]);
  readonly failure = signal('');
  term = '';

  private readonly typed$ = new Subject<string>();
  private sub!: Subscription;

  ngOnInit(): void {
    this.meta.updateTag({
      name: 'description',
      content: 'Escribe parte del nombre y encuentra cualquier carta de Yu-Gi-Oh! con su tipo, ATK y DEF. Resultados al instante.',
    });
    this.sub = this.typed$
      .pipe(
        debounceTime(400),
        distinctUntilChanged(),
        tap(t => {
          if (!t.trim()) { this.phase.set('idle'); this.hits.set([]); }
          else { this.phase.set('loading'); }
        }),
        filter(t => !!t.trim()),
        switchMap(t =>
          this.api.searchCards(t).pipe(
            catchError(err => { this.failure.set(err.message); this.phase.set('error'); return EMPTY; }),
          ),
        ),
      )
      .subscribe(res => {
        const list = res.data ?? [];
        this.hits.set(list);
        this.phase.set(list.length > 0 ? 'success' : 'empty');
      });
  }

  onType(value: string): void { this.typed$.next(value); }

  ngOnDestroy(): void { this.sub?.unsubscribe(); }
}
