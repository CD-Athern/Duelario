import { Routes } from '@angular/router';
import { HuntPage } from './pages/hunt/hunt.page';
import { ArchivePage } from './pages/archive/archive.page';

export const routes: Routes = [
  { path: '', redirectTo: 'buscar', pathMatch: 'full' },
  { path: 'buscar', component: HuntPage, title: 'Buscar cartas Yu-Gi-Oh! por nombre | Duelario' },
  { path: 'ojos-azules', component: ArchivePage, title: 'Archivo Blue-Eyes: impresiones, rarezas y precios | Duelario' },
  { path: '**', redirectTo: 'buscar' },
];
